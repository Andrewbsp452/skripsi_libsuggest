<?php
/**
 * LibSuggest — tambah_buku.php
 * Halaman untuk petugas menambah buku ke koleksi via ISBN
 */
require_once __DIR__ . '/config/session.php';
requirePetugas();
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LibSuggest — Tambah Buku</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
  <style>
    .isbn-search-section {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      border-radius: 12px;
      margin-bottom: 40px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .isbn-search-section h2 {
      margin: 0 0 10px 0;
      font-size: 24px;
    }
    .isbn-search-section p {
      margin: 0 0 20px 0;
      opacity: 0.95;
      font-size: 15px;
    }
    .isbn-input-wrap {
      display: flex;
      gap: 10px;
      margin-bottom: 15px;
    }
    .isbn-input-wrap input {
      flex: 1;
      padding: 12px 16px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-family: 'Courier New', monospace;
    }
    .isbn-input-wrap button {
      padding: 12px 24px;
      background: rgba(255,255,255,0.2);
      border: 2px solid white;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    .isbn-input-wrap button:hover {
      background: white;
      color: #667eea;
    }
    .isbn-input-wrap button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .isbn-help {
      font-size: 13px;
      opacity: 0.85;
    }
    .search-result {
      background: white;
      border: 1px solid var(--gray-200);
      border-radius: 12px;
      padding: 24px;
      margin-bottom: 20px;
    }
    .book-detail-row {
      display: flex;
      gap: 20px;
      margin-bottom: 20px;
    }
    .book-detail-cover {
      flex: 0 0 120px;
      height: 180px;
      background: var(--gray-100);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 48px;
      overflow: hidden;
    }
    .book-detail-cover img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .book-detail-info {
      flex: 1;
    }
    .book-detail-title {
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 10px;
      color: var(--gray-900);
    }
    .book-detail-meta {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-bottom: 15px;
    }
    .book-detail-meta-row {
      display: flex;
      gap: 10px;
      font-size: 14px;
      color: var(--gray-600);
    }
    .book-detail-meta-label {
      font-weight: 600;
      color: var(--gray-700);
      min-width: 100px;
    }
    .save-button-wrap {
      display: flex;
      gap: 10px;
      margin-top: 20px;
    }
    .btn-save-book {
      flex: 1;
      padding: 12px 20px;
      background: var(--primary-500);
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    .btn-save-book:hover {
      background: var(--primary-600);
    }
    .btn-save-book:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .btn-reset {
      padding: 12px 20px;
      background: var(--gray-200);
      color: var(--gray-700);
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    .btn-reset:hover {
      background: var(--gray-300);
    }
    .error-message {
      background: #fee;
      border: 1px solid #fcc;
      color: #c33;
      padding: 12px 16px;
      border-radius: 8px;
      margin-bottom: 20px;
      display: none;
    }
    .error-message.show {
      display: block;
    }
    .success-message {
      background: #efe;
      border: 1px solid #cfc;
      color: #3c3;
      padding: 12px 16px;
      border-radius: 8px;
      margin-bottom: 20px;
      display: none;
    }
    .success-message.show {
      display: block;
    }
    .loading-spinner {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 2px solid rgba(255,255,255,0.3);
      border-top-color: white;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  </style>
</head>
<body>

<!-- ── Topbar ── -->
<header class="topbar">
  <div class="container topbar-inner">
    <div class="topbar-brand">
      <div class="brand-icon">
        <svg viewBox="0 0 24 24"><path d="M4 4h4v16H4zM10 4h4v16h-4zM16 4h4v16h-4z"/></svg>
      </div>
      <div>
        <div class="brand-name">LibSuggest</div>
        <div class="brand-sub">Perpustakaan Unika</div>
      </div>
    </div>

    <nav class="topbar-nav">
      <a href="index.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Cari Buku
      </a>
      <a href="riwayat.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        Riwayat Saya
      </a>
      <a href="dashboard.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Dashboard
      </a>
      <a href="tambah_buku.php" class="nav-link active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Tambah Buku
      </a>
      <a href="import_csv.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
        Import CSV
      </a>
    </nav>

    <div class="topbar-user">
      <div class="user-avatar">
        <?php if (!empty($user['photo'])): ?>
          <img src="<?= htmlspecialchars($user['photo']) ?>" alt="Foto profil <?= htmlspecialchars($user['name']) ?>">
        <?php else: ?>
          <?= htmlspecialchars($user['initials']) ?>
        <?php endif; ?>
      </div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($user['name']) ?></div>
        <div class="user-role"><?= htmlspecialchars($user['display_role']) ?></div>
      </div>
    </div>
  </div>
</header>

<!-- ── Main ── -->
<main class="container">
  <div class="page-header">
    <h1 class="page-title">Tambah Buku ke Koleksi</h1>
    <p class="page-sub">Masukkan ISBN buku untuk menambahkan ke daftar koleksi usul perpustakaan.</p>
  </div>

  <!-- ISBN Search Section -->
  <div class="isbn-search-section">
    <h2>Cari Buku dengan ISBN</h2>
    <p>Masukkan nomor ISBN untuk mencari data buku dari Google Books</p>
    <div class="isbn-input-wrap">
      <input 
        type="text" 
        id="isbn-input" 
        placeholder="Contoh: 978-6024353450 atau 9786024353450"
        autocomplete="off"
      >
      <button id="btn-search-isbn">
        <span id="btn-text">Cari ISBN</span>
        <span id="btn-spinner" class="loading-spinner" style="display:none; margin-left:8px;"></span>
      </button>
    </div>
    <div class="isbn-help">
      💡 ISBN adalah kode 10 atau 13 digit yang biasanya terletak di belakang buku atau barcode
    </div>
  </div>

  <div id="error-message" class="error-message"></div>
  <div id="success-message" class="success-message"></div>

  <!-- Search Result -->
  <div id="search-result" style="display:none;">
    <!-- Will be populated by JS -->
  </div>
</main>

<script src="assets/js/app.js"></script>
<script>
// ────────────────────────────────────────
// ISBN Search Handler
// ────────────────────────────────────────

const isbnInput = document.getElementById('isbn-input');
const btnSearch = document.getElementById('btn-search-isbn');
const btnText = document.getElementById('btn-text');
const btnSpinner = document.getElementById('btn-spinner');
const errorMsg = document.getElementById('error-message');
const successMsg = document.getElementById('success-message');
const searchResult = document.getElementById('search-result');

let currentBook = null; // Menyimpan data buku yang dicari

// Allow search on Enter key
isbnInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    searchISBN();
  }
});

btnSearch.addEventListener('click', searchISBN);

async function searchISBN() {
  const isbn = isbnInput.value.trim();
  
  // Validasi
  if (!isbn) {
    showError('Masukkan ISBN terlebih dahulu');
    return;
  }
  
  if (!/^\d{10,13}$/.test(isbn.replace(/-/g, ''))) {
    showError('ISBN harus berisi 10 atau 13 digit angka');
    return;
  }

  // Disable button & show spinner
  btnSearch.disabled = true;
  btnText.textContent = 'Mencari...';
  btnSpinner.style.display = 'inline-block';
  hideError();
  hideSuccess();

  try {
    const response = await fetch('api/isbn_search.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ isbn: isbn.replace(/-/g, '') })
    });

    const data = await response.json();

    if (!response.ok || data.error) {
      showError(data.error || 'Gagal mencari buku');
      return;
    }

    if (!data.book) {
      showError('Buku dengan ISBN ini tidak ditemukan di Google Books');
      return;
    }

    currentBook = data.book;
    displaySearchResult(data.book);
    hideError();
  } catch (err) {
    showError('Terjadi kesalahan: ' + err.message);
  } finally {
    btnSearch.disabled = false;
    btnText.textContent = 'Cari ISBN';
    btnSpinner.style.display = 'none';
  }
}

function displaySearchResult(book) {
  const html = `
    <div class="search-result">
      <div class="book-detail-row">
        <div class="book-detail-cover">
          ${book.cover_url ? `<img src="${escapeHtml(book.cover_url)}" alt="${escapeHtml(book.title)}">` : '📚'}
        </div>
        <div class="book-detail-info">
          <div class="book-detail-title">${escapeHtml(book.title)}</div>
          <div class="book-detail-meta">
            <div class="book-detail-meta-row">
              <span class="book-detail-meta-label">Penulis:</span>
              <span>${book.authors && book.authors.length > 0 ? book.authors.join(', ') : 'Tidak tersedia'}</span>
            </div>
            <div class="book-detail-meta-row">
              <span class="book-detail-meta-label">ISBN:</span>
              <span>${escapeHtml(book.isbn || 'Tidak tersedia')}</span>
            </div>
            <div class="book-detail-meta-row">
              <span class="book-detail-meta-label">Tahun:</span>
              <span>${book.published_year || 'Tidak tersedia'}</span>
            </div>
            <div class="book-detail-meta-row">
              <span class="book-detail-meta-label">Penerbit:</span>
              <span>${book.publisher ? escapeHtml(book.publisher) : 'Tidak tersedia'}</span>
            </div>
            ${book.page_count ? `
            <div class="book-detail-meta-row">
              <span class="book-detail-meta-label">Halaman:</span>
              <span>${book.page_count}</span>
            </div>
            ` : ''}
          </div>
          <div class="save-button-wrap">
            <button class="btn-save-book" id="btn-save-book" onclick="saveBook()">
              Tambah ke Koleksi
            </button>
            <button class="btn-reset" onclick="resetForm()">Reset</button>
          </div>
        </div>
      </div>
    </div>
  `;
  searchResult.innerHTML = html;
  searchResult.style.display = 'block';
  
  // Scroll to result
  searchResult.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function saveBook() {
  if (!currentBook) {
    showError('Data buku tidak tersedia');
    return;
  }

  const btn = document.getElementById('btn-save-book');
  btn.disabled = true;
  btn.textContent = 'Menyimpan...';

  try {
    const response = await fetch('api/tambah_buku.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ book: currentBook })
    });

    const data = await response.json();

    if (!response.ok || data.error) {
      showError(data.error || 'Gagal menyimpan buku');
      btn.disabled = false;
      btn.textContent = 'Tambah ke Koleksi';
      return;
    }

    showSuccess('✓ Buku berhasil ditambahkan ke koleksi!');
    resetForm();
  } catch (err) {
    showError('Terjadi kesalahan: ' + err.message);
    btn.disabled = false;
    btn.textContent = 'Tambah ke Koleksi';
  }
}

function resetForm() {
  isbnInput.value = '';
  searchResult.style.display = 'none';
  currentBook = null;
  isbnInput.focus();
}

function showError(msg) {
  errorMsg.textContent = msg;
  errorMsg.classList.add('show');
  successMsg.classList.remove('show');
}

function hideError() {
  errorMsg.classList.remove('show');
}

function hideSuccess() {
  successMsg.classList.remove('show');
}

function showSuccess(msg) {
  successMsg.textContent = msg;
  successMsg.classList.add('show');
  errorMsg.classList.remove('show');
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}
</script>
</body>
</html>
