<?php
/**
 * LibSuggest — riwayat.php
 * Riwayat usulan & dukungan milik user yang sedang login.
 */
require_once __DIR__ . '/config/session.php';
requireLogin();
$user = currentUser();
$initials = strtoupper(implode('', array_map(fn($w) => $w[0], explode(' ', $user['name']))));
$initials = mb_substr($initials, 0, 2);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= htmlspecialchars(getCsrfToken(), ENT_QUOTES, 'UTF-8') ?>">
  <title>LibSuggest — Riwayat Usulan</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
</head>
<body>

<header class="topbar">
  <div class="container topbar-inner">
    <!-- Logo Dropdown -->
    <div class="topbar-brand-dropdown">
      <button class="topbar-brand" id="brand-menu-toggle" aria-label="Menu">
        <div class="brand-icon">
          <svg viewBox="0 0 24 24"><path d="M4 4h4v16H4zM10 4h4v16h-4zM16 4h4v16h-4z"/></svg>
        </div>
        <div>
          <div class="brand-name">LibSuggest</div>
          <div class="brand-sub">Perpustakaan Unika</div>
        </div>
      </button>
      
      <!-- Dropdown Menu -->
      <div class="brand-dropdown" id="brand-dropdown">
        <a href="dashboard.php" class="dropdown-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
          Dashboard
        </a>
        <a href="logout.php" class="dropdown-item logout">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
          Logout
        </a>
      </div>
    </div>
    <nav class="topbar-nav">
      <a href="index.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Cari Buku
      </a>
      <a href="riwayat.php" class="nav-link active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        Riwayat Saya
      </a>
      <a href="dashboard.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Dashboard
      </a>
      <?php if ($user['role'] === 'pegawai'): ?>
      <!-- <a href="tambah_buku.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Tambah Buku
      </a> -->
      <a href="import_csv.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
        Import CSV
      </a>
      <?php endif; ?>
    </nav>
    <div class="topbar-user">
      <div class="user-avatar">
        <?php if ($user['photo']): ?>
          <img src="<?= htmlspecialchars($user['photo']) ?>" alt="">
        <?php else: ?>
          <?= htmlspecialchars($initials) ?>
        <?php endif; ?>
      </div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($user['name']) ?></div>
        <div class="user-role"><?= htmlspecialchars($user['display_role']) ?></div>
      </div>
    </div>
  </div>
</header>

<main class="container">
  <div class="page-header">
    <h1 class="page-title">Riwayat Saya</h1>
    <p class="page-sub">Usulan buku dan dukungan yang pernah kamu berikan.</p>
  </div>

  <!-- Tab list (dikendalikan JS) -->
  <div class="tab-list">
    <button class="tab-btn active" id="tab-proposal">📋 Usulan Saya</button>
    <button class="tab-btn"        id="tab-vote">👍 Buku yang Didukung</button>
  </div>

  <!-- Pane konten (diisi oleh JS) -->
  <div id="riwayat-wrap">
    <!-- Loading placeholder -->
    <p style="color:var(--gray-400);font-size:13px">Memuat...</p>
  </div>

  <!-- Pane dirender JS, tapi elemen container perlu ada di DOM -->
  <div id="pane-proposal" class="riwayat-grid" style="display:none"></div>
  <div id="pane-vote"     class="riwayat-grid" style="display:none"></div>
</main>

<div id="chat-modal-backdrop" class="modal-backdrop">
  <section class="modal chat-modal" role="dialog" aria-modal="true" aria-labelledby="chat-modal-title">
    <div class="modal-header">
      <div>
        <h2 class="modal-title" id="chat-modal-title">Percakapan Usulan</h2>
        <p class="form-hint" id="chat-modal-subtitle"></p>
      </div>
      <button id="chat-modal-close" class="modal-close" type="button" aria-label="Tutup">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
    <div id="chat-messages" class="chat-messages" aria-live="polite"></div>
    <form id="chat-message-form" class="chat-compose">
      <textarea id="chat-message-input" class="form-textarea" rows="2" maxlength="2000" placeholder="Tulis pesan..." required></textarea>
      <button id="chat-send-button" type="submit" class="btn btn-primary">Kirim</button>
    </form>
  </section>
</div>

<script>
  window.LIBSUGGEST_CHAT_ROLE = <?= isPetugas() ? "'admin'" : "'pengusul'" ?>;
</script>
<script src="assets/js/app.js"></script>
<script src="assets/js/chat.js"></script>
</body>
</html>