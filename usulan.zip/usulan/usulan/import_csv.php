<?php
/**
 * LibSuggest — import_csv.php
 * Halaman untuk petugas mengimport koleksi buku dari CSV
 */
require_once __DIR__ . '/config/session.php';
requirePetugas();
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LibSuggest — Import CSV</title>
  <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
  <!-- SheetJS for Excel parsing - dengan fallback -->
  <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
  <style>
    .import-section {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      border-radius: 12px;
      margin-bottom: 40px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .import-section h2 {
      margin: 0 0 10px 0;
      font-size: 24px;
    }
    .import-section p {
      margin: 0 0 20px 0;
      opacity: 0.95;
      font-size: 15px;
    }
    .file-upload-wrap {
      background: rgba(255,255,255,0.1);
      border: 2px dashed white;
      border-radius: 8px;
      padding: 40px 20px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    .file-upload-wrap:hover {
      background: rgba(255,255,255,0.2);
    }
    .file-upload-wrap.dragover {
      background: rgba(255,255,255,0.3);
      transform: scale(1.02);
    }
    .file-upload-icon {
      font-size: 48px;
      margin-bottom: 10px;
    }
    .file-upload-label {
      display: block;
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 5px;
    }
    .file-upload-hint {
      font-size: 13px;
      opacity: 0.85;
    }
    #file-input {
      display: none;
    }
    .card {
      background: white;
      border: 1px solid var(--gray-200);
      border-radius: 12px;
      padding: 24px;
      margin-bottom: 20px;
    }
    .card-title {
      font-size: 16px;
      font-weight: 700;
      margin-bottom: 15px;
      color: var(--gray-900);
    }
    .template-section {
      margin-bottom: 20px;
    }
    .template-section h3 {
      font-size: 14px;
      font-weight: 600;
      color: var(--gray-700);
      margin-bottom: 10px;
    }
    .template-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
      margin-bottom: 15px;
    }
    .template-table th {
      background: var(--gray-100);
      padding: 10px;
      text-align: left;
      font-weight: 600;
      color: var(--gray-700);
      border: 1px solid var(--gray-200);
    }
    .template-table td {
      padding: 10px;
      border: 1px solid var(--gray-200);
      color: var(--gray-600);
    }
    .template-table .required {
      color: #c33;
    }
    .download-btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 16px;
      background: var(--primary-500);
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    .download-btn:hover {
      background: var(--primary-600);
    }
    .preview-section {
      display: none;
    }
    .preview-section.show {
      display: block;
    }
    .preview-info {
      background: #eef;
      border: 1px solid #ccf;
      color: #33c;
      padding: 12px 16px;
      border-radius: 8px;
      margin-bottom: 20px;
    }
    .preview-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
      margin-bottom: 20px;
      max-height: 400px;
      overflow-y: auto;
    }
    .preview-table th {
      background: var(--primary-500);
      color: white;
      padding: 10px;
      text-align: left;
      font-weight: 600;
      position: sticky;
      top: 0;
    }
    .preview-table td {
      padding: 10px;
      border: 1px solid var(--gray-200);
      color: var(--gray-700);
    }
    .preview-table tr:nth-child(even) {
      background: var(--gray-50);
    }
    .action-buttons {
      display: flex;
      gap: 10px;
      margin-top: 20px;
    }
    .btn {
      padding: 12px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    .btn-primary {
      background: var(--primary-500);
      color: white;
    }
    .btn-primary:hover:not(:disabled) {
      background: var(--primary-600);
    }
    .btn-outline {
      background: transparent;
      color: var(--gray-700);
      border: 2px solid var(--gray-300);
    }
    .btn-outline:hover:not(:disabled) {
      background: var(--gray-50);
      border-color: var(--gray-400);
    }
    .btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    .error-message {
      background: #fee;
      border: 1px solid #fcc;
      color: #c33;
      padding: 12px 16px;
      border-radius: 8px;
      margin-bottom: 20px;
      display: none;
    }
    .error-message.show {
      display: block;
    }
    .success-message {
      background: #efe;
      border: 1px solid #cfc;
      color: #3c3;
      padding: 12px 16px;
      border-radius: 8px;
      margin-bottom: 20px;
      display: none;
    }
    .success-message.show {
      display: block;
    }
    .spinner {
      display: inline-block;
      width: 16px;
      height: 16px;
      border: 2px solid rgba(255,255,255,0.3);
      border-top-color: white;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .import-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 15px;
      margin-top: 20px;
    }
    .stat-box {
      background: var(--gray-50);
      padding: 15px;
      border-radius: 8px;
      border: 1px solid var(--gray-200);
    }
    .stat-label {
      font-size: 12px;
      color: var(--gray-600);
      text-transform: uppercase;
      font-weight: 600;
      margin-bottom: 5px;
    }
    .stat-value {
      font-size: 24px;
      font-weight: 700;
      color: var(--primary-500);
    }
  </style>
</head>
<body>

<!-- ── Topbar ── -->
<header class="topbar">
  <div class="container topbar-inner">
    <div class="topbar-brand">
      <div class="brand-icon">
        <svg viewBox="0 0 24 24"><path d="M4 4h4v16H4zM10 4h4v16h-4zM16 4h4v16h-4z"/></svg>
      </div>
      <div>
        <div class="brand-name">LibSuggest</div>
        <div class="brand-sub">Perpustakaan Unika</div>
      </div>
    </div>

    <nav class="topbar-nav">
      <a href="index.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        Cari Buku
      </a>
      <a href="riwayat.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        Riwayat Saya
      </a>
      <a href="dashboard.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        Dashboard
      </a>
      <!-- <a href="tambah_buku.php" class="nav-link">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Tambah Buku
      </a> -->
      <a href="import_csv.php" class="nav-link active">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
        Import CSV
      </a>
    </nav>

    <div class="topbar-user">
      <div class="user-avatar">
        <?php if (!empty($user['photo'])): ?>
          <img src="<?= htmlspecialchars($user['photo']) ?>" alt="Foto profil <?= htmlspecialchars($user['name']) ?>">
        <?php else: ?>
          <?= htmlspecialchars($user['initials']) ?>
        <?php endif; ?>
      </div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($user['name']) ?></div>
        <div class="user-role"><?= htmlspecialchars($user['display_role']) ?></div>
      </div>
    </div>
  </div>
</header>

<!-- ── Main ── -->
<main class="container">
  <div class="page-header">
    <h1 class="page-title">Import Koleksi Buku</h1>
    <p class="page-sub">Upload file CSV untuk menambahkan koleksi buku ke perpustakaan secara massal.</p>
  </div>

  <div id="error-message" class="error-message"></div>
  <div id="success-message" class="success-message"></div>

  <!-- Upload Section -->
  <div class="import-section">
    <h2>Upload File</h2>
    <p>Drag & drop atau klik untuk memilih file CSV atau Excel dari komputer Anda</p>
    <div class="file-upload-wrap" id="file-upload-wrap">
      <div class="file-upload-icon">📁</div>
      <span class="file-upload-label">Pilih file CSV atau Excel</span>
      <span class="file-upload-hint">File berformat CSV atau XLSX, maks. 5 MB</span>
    </div>
    <input type="file" id="file-input" accept=".csv,.xlsx,.xls" />
  </div>

  <!-- Template Section -->
  <div class="card">
    <div class="card-title">📋 Format File (CSV atau Excel)</div>
    
    <div class="template-section">
      <h3>Kolom yang Diperlukan:</h3>
      <table class="template-table">
        <thead>
          <tr>
            <th>Kolom <span class="required">*</span></th>
            <th>Alias</th>
            <th>Deskripsi</th>
            <th>Contoh</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>SKU</strong></td>
            <td>Kode</td>
            <td>Kode buku unik</td>
            <td>DP12396A</td>
          </tr>
          <tr>
            <td><strong>ISBN</strong> <span class="required">*</span></td>
            <td>—</td>
            <td>Nomor ISBN (10 atau 13 digit)</td>
            <td>978-634-0</td>
          </tr>
          <tr>
            <td><strong>Judul</strong> <span class="required">*</span></td>
            <td>Title, Judul Buku</td>
            <td>Judul buku</td>
            <td>Petualangan Seru</td>
          </tr>
          <tr>
            <td><strong>Penulis</strong></td>
            <td>Authors, Pengarang</td>
            <td>Nama penulis (pisahkan dengan semicolon jika multiple)</td>
            <td>Endang Fachrudin; Nama Lain</td>
          </tr>
          <tr>
            <td><strong>Kategori</strong></td>
            <td>Category, Kategori 1</td>
            <td>Kategori utama buku</td>
            <td>UMUM</td>
          </tr>
          <tr>
            <td><strong>SubKategori</strong></td>
            <td>Sub Kategori, SubCategory, Kategori 2</td>
            <td>Sub kategori buku</td>
            <td>Anak-Anak</td>
          </tr>
          <tr>
            <td><strong>Tahun</strong></td>
            <td>PublishedYear, Tahun Terbit, Ctkn Thn</td>
            <td>Tahun penerbitan (4 digit)</td>
            <td>2025</td>
          </tr>
          <tr>
            <td><strong>Ukuran</strong></td>
            <td>Size, Format</td>
            <td>Ukuran buku</td>
            <td>C5</td>
          </tr>
          <tr>
            <td><strong>Halaman</strong></td>
            <td>Hlm, Hal, PageCount</td>
            <td>Jumlah halaman</td>
            <td>280</td>
          </tr>
          <tr>
            <td><strong>Spek</strong></td>
            <td>Specification, Spesifikasi</td>
            <td>Spesifikasi (jenis kertas, dll)</td>
            <td>FC Bookpaper</td>
          </tr>
          <tr>
            <td><strong>Harga</strong></td>
            <td>Price</td>
            <td>Harga buku (angka saja)</td>
            <td>735000</td>
          </tr>
          <tr>
            <td><strong>Publisher</strong></td>
            <td>Penerbit</td>
            <td>Nama penerbit (opsional)</td>
            <td>Penerbit Unika</td>
          </tr>
          <tr>
            <td><strong>Description</strong></td>
            <td>Deskripsi, Sinopsis, Ket</td>
            <td>Keterangan tambahan buku (opsional)</td>
            <td>Tersedia File Digital</td>
          </tr>
          <tr>
            <td><strong>Language</strong></td>
            <td>Bahasa</td>
            <td>Bahasa buku, default <code>id</code></td>
            <td>id</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="template-section">
      <h3>Catatan:</h3>
      <ul style="margin: 0; padding-left: 20px; color: var(--gray-700); font-size: 14px;">
        <li>Kolom yang ditandai dengan <span class="required">*</span> adalah wajib diisi</li>
        <li>Kolom lainnya bersifat opsional</li>
        <li>Format ideal tetap memakai header standar: <strong>SKU, ISBN, Judul, Penulis, Kategori, SubKategori, Tahun, Ukuran, Halaman, Spek, Harga, Publisher, Description, Language</strong></li>
        <li>File katalog lama seperti <strong>Judul buku</strong>, <strong>Hal</strong>, <strong>Ctkn Thn</strong>, <strong>Kategori 1/2</strong>, dan <strong>Ket</strong> tetap dikenali otomatis</li>
        <li>Gunakan semicolon (;) untuk memisahkan multiple penulis</li>
        <li>Buku dengan ISBN yang sama akan di-skip (tidak ada duplikat)</li>
        <li>File bisa berformat <strong>CSV</strong> (encoding UTF-8) atau <strong>Excel (.xlsx/.xls)</strong></li>
        <li>Untuk Excel, pastikan data berada di sheet pertama (Sheet1)</li>
      </ul>
    </div>

    <button class="download-btn" onclick="downloadTemplate()">
      📥 Download Template (CSV)
    </button>
  </div>

  <!-- Preview Section -->
  <div class="preview-section" id="preview-section">
    <div class="card">
      <div class="card-title">👁️ Preview Data</div>
      <div class="preview-info" id="preview-info"></div>
      
      <div style="overflow-x: auto;">
        <table class="preview-table" id="preview-table">
          <thead></thead>
          <tbody></tbody>
        </table>
      </div>

      <div class="import-stats" id="import-stats"></div>

      <div class="action-buttons">
        <button class="btn btn-outline" onclick="resetUpload()">Batal</button>
        <button class="btn btn-primary" id="btn-import" onclick="confirmImport()">
          <span id="import-text">Import ke Database</span>
          <span id="import-spinner" class="spinner" style="display:none; margin-left:8px;"></span>
        </button>
      </div>
    </div>
  </div>
</main>

<script>
// ────────────────────────────────────────
// File Upload Handler
// ────────────────────────────────────────

const fileUploadWrap = document.getElementById('file-upload-wrap');
const fileInput = document.getElementById('file-input');
const errorMsg = document.getElementById('error-message');
const successMsg = document.getElementById('success-message');
const previewSection = document.getElementById('preview-section');

let parsedData = null;

// Click to upload
fileUploadWrap.addEventListener('click', () => fileInput.click());

// Drag & drop
fileUploadWrap.addEventListener('dragover', (e) => {
  e.preventDefault();
  fileUploadWrap.classList.add('dragover');
});

fileUploadWrap.addEventListener('dragleave', () => {
  fileUploadWrap.classList.remove('dragover');
});

fileUploadWrap.addEventListener('drop', (e) => {
  e.preventDefault();
  fileUploadWrap.classList.remove('dragover');
  const files = e.dataTransfer.files;
  if (files.length > 0) {
    handleFile(files[0]);
  }
});

// File input change
fileInput.addEventListener('change', (e) => {
  if (e.target.files.length > 0) {
    handleFile(e.target.files[0]);
  }
});

async function handleFile(file) {
  hideError();
  hideSuccess();
  
  // Validasi file
  const validExtensions = ['.csv', '.xlsx', '.xls'];
  const fileName = file.name.toLowerCase();
  const isValidType = validExtensions.some(ext => fileName.endsWith(ext));
  
  if (!isValidType) {
    showError('File harus berformat CSV, XLSX, atau XLS');
    return;
  }
  
  if (file.size > 5 * 1024 * 1024) {
    showError('Ukuran file terlalu besar (max 5 MB)');
    return;
  }

  // Check Excel library for xlsx files
  if ((fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) && typeof XLSX === 'undefined') {
    showError('Library Excel sedang loading... Silakan tunggu beberapa saat dan coba lagi');
    console.warn('XLSX library not yet loaded');
    return;
  }

  // Determine file type dan parse
  try {
    if (fileName.endsWith('.csv')) {
      handleCSVFile(file);
    } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
      handleExcelFile(file);
    }
  } catch (err) {
    showError('Gagal membaca file: ' + err.message);
    console.error('File handling error:', err);
  }
}

function handleCSVFile(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const csv = e.target.result;
      parsedData = parseCSV(csv);
      
      if (!parsedData || parsedData.length === 0) {
        showError('File CSV kosong atau tidak valid');
        return;
      }

      validateAndProcessData();
    } catch (err) {
      showError('Gagal membaca file CSV: ' + err.message);
    }
  };
  reader.readAsText(file);
}

function handleExcelFile(file) {
  // Check if XLSX library is loaded
  if (typeof XLSX === 'undefined') {
    showError('Library Excel belum selesai loading. Silakan refresh halaman dan coba lagi.');
    return;
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      
      // Get first sheet
      const firstSheetName = workbook.SheetNames[0];
      if (!firstSheetName) {
        showError('File Excel tidak memiliki sheet yang valid');
        return;
      }

      const worksheet = workbook.Sheets[firstSheetName];
      
      // Convert to JSON array
      const jsonData = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,  // Return as array of arrays
        defval: ''  // Default value for empty cells
      });

      if (jsonData.length < 2) {
        showError('File Excel kosong atau tidak valid');
        return;
      }

      // Convert array format to object format (like CSV)
      parsedData = excelToJSON(jsonData);
      
      if (!parsedData || parsedData.length === 0) {
        showError('Tidak ada data ditemukan di Excel');
        return;
      }

      validateAndProcessData();
    } catch (err) {
      console.error('Excel parsing error:', err);
      showError('Gagal membaca file Excel: ' + err.message);
    }
  };
  
  reader.onerror = () => {
    showError('Gagal membaca file Excel');
  };
  
  reader.readAsArrayBuffer(file);
}

function excelToJSON(arrayData) {
  if (arrayData.length < 2) return null;
  
  const headers = arrayData[0];
  const data = [];
  
  for (let i = 1; i < arrayData.length; i++) {
    if (!arrayData[i] || arrayData[i].every(val => !val)) {
      continue;  // Skip empty rows
    }
    
    const row = {};
    headers.forEach((header, idx) => {
      row[header] = (arrayData[i][idx] || '').toString().trim();
    });
    
    data.push(row);
  }
  
  return data;
}

function validateAndProcessData() {
  // Validasi kolom dan normalize header (support English & Indonesia)
  const headerMapping = {
    // Core fields
    'sku': ['sku', 'kode'],
    'isbn': ['isbn'],
    'judul': ['judul', 'title', 'judulbuku'],
    'penulis': ['penulis', 'pengarang', 'authors'],
    
    // Book details
    'kategori': ['kategori', 'category', 'kategori1'],
    'sub_kategori': ['sub_kategori', 'subkategori', 'subcategory', 'sub_category', 'kategori2'],
    'tahun': ['tahun', 'publishedyear', 'tahun_terbit', 'year', 'ctknthn'],
    'ukuran': ['ukuran', 'size', 'dimensi', 'format'],
    'halaman': ['halaman', 'pagecount', 'page_count', 'hlm', 'hal'],
    'spek': ['spek', 'specification', 'spesifikasi'],
    'harga': ['harga', 'price', 'hargajual'],
    
    // Legacy/optional fields
    'publisher': ['publisher', 'penerbit'],
    'description': ['description', 'deskripsi', 'sinopsis', 'ket'],
    'language': ['language', 'bahasa']
  };

  const originalHeaders = Object.keys(parsedData[0]);
  const normalizedHeaders = normalizeHeaders(originalHeaders, headerMapping);
  
  // Check required columns (isbn & judul)
  const hasIsbn = normalizedHeaders.some(h => h === 'isbn');
  const hasJudul = normalizedHeaders.some(h => h === 'judul');
  
  if (!hasIsbn || !hasJudul) {
    const missing = [];
    if (!hasIsbn) missing.push('ISBN');
    if (!hasJudul) missing.push('Judul/Title');
    showError(`Kolom yang hilang: ${missing.join(', ')}`);
    return;
  }

  // Remap data keys to normalized English names
  parsedData = parsedData.map(row => {
    const newRow = {};
    Object.keys(row).forEach((origKey, idx) => {
      const normalizedKey = normalizedHeaders[idx];
      newRow[normalizedKey] = row[origKey];
    });
    return newRow;
  });

  displayPreview();
}

function parseCSV(csv) {
  const lines = csv.trim().split('\n');
  if (lines.length < 2) return null;

  // Parse header dengan proper CSV parser
  const header = parseCSVLine(lines[0]);
  if (!header || header.length === 0) return null;

  const headerLower = header.map(h => h.toLowerCase());

  // Parse data
  const data = [];
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue;

    // Proper CSV parser yang handle quoted values
    const values = parseCSVLine(lines[i]);
    
    if (!values || values.length === 0) {
      console.warn(`Row ${i+1} is empty, skipping`);
      continue;
    }

    if (values.length !== header.length) {
      console.warn(`Row ${i+1} has ${values.length} columns but header has ${header.length}, skipping`);
      continue;
    }

    const row = {};
    header.forEach((col, idx) => {
      row[col] = values[idx];
    });
    
    data.push(row);
  }

  return data;
}

function parseCSVLine(line) {
  const result = [];
  let current = '';
  let insideQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        // Escaped quote
        current += '"';
        i++;
      } else {
        // Toggle quote state
        insideQuotes = !insideQuotes;
      }
    } else if (char === ',' && !insideQuotes) {
      // Field separator
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }

  // Add last field
  result.push(current.trim());

  return result;
}

function normalizeHeaders(headers, mapping) {
  return headers.map(header => {
    const normalized = header.trim().toLowerCase().replace(/[\s_-]/g, '');
    
    // Find matching normalized key
    for (const [key, variants] of Object.entries(mapping)) {
      for (const variant of variants) {
        if (normalized === variant.toLowerCase().replace(/[\s_-]/g, '')) {
          return key;
        }
      }
    }
    
    // If no match found, return original normalized
    return normalized;
  });
}

function displayPreview() {
  const stats = analyzeData();
  
  const info = document.getElementById('preview-info');
  info.innerHTML = `
    ✓ File berhasil diparsing. 
    Total <strong>${parsedData.length}</strong> buku siap diimport.
  `;

  // Render table
  const thead = document.querySelector('#preview-table thead');
  const tbody = document.querySelector('#preview-table tbody');
  
  const cols = Object.keys(parsedData[0]);
  thead.innerHTML = `<tr>${cols.map(col => `<th>${escapeHtml(col)}</th>`).join('')}</tr>`;
  
  tbody.innerHTML = parsedData.slice(0, 10).map(row => {
    return `<tr>${cols.map(col => {
      let val = row[col] || '';
      if (col.toLowerCase() === 'description' && val.length > 50) {
        val = val.substring(0, 50) + '...';
      }
      return `<td>${escapeHtml(val)}</td>`;
    }).join('')}</tr>`;
  }).join('');

  // Render stats
  const statsHtml = document.getElementById('import-stats');
  statsHtml.innerHTML = `
    <div class="stat-box">
      <div class="stat-label">Total Buku</div>
      <div class="stat-value">${stats.total}</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Dengan ISBN</div>
      <div class="stat-value">${stats.withIsbn}</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Duplikat ISBN</div>
      <div class="stat-value">${stats.duplicateIsbn}</div>
    </div>
  `;

  previewSection.classList.add('show');
  previewSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function analyzeData() {
  const stats = {
    total: parsedData.length,
    withIsbn: 0,
    duplicateIsbn: 0,
  };

  const isbnSet = new Set();
  parsedData.forEach(row => {
    // Now looking for normalized 'isbn' key
    const isbn = row['isbn'] || '';
    if (isbn.trim()) {
      stats.withIsbn++;
      if (isbnSet.has(isbn)) {
        stats.duplicateIsbn++;
      }
      isbnSet.add(isbn);
    }
  });

  return stats;
}

async function confirmImport() {
  if (!parsedData || parsedData.length === 0) {
    showError('Tidak ada data untuk diimport');
    return;
  }

  const btn = document.getElementById('btn-import');
  const text = document.getElementById('import-text');
  const spinner = document.getElementById('import-spinner');

  btn.disabled = true;
  text.textContent = 'Mengimport...';
  spinner.style.display = 'inline-block';
  hideError();
  hideSuccess();

  try {
    const response = await fetch('api/import_csv.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ books: parsedData })
    });

    const result = await response.json();

    if (!response.ok || result.error) {
      showError(result.error || 'Gagal mengimport data');
      btn.disabled = false;
      text.textContent = 'Import ke Database';
      spinner.style.display = 'none';
      return;
    }

    showSuccess(`✓ Berhasil mengimport ${result.imported} buku! ${result.skipped > 0 ? `(${result.skipped} dilewati karena duplikat)` : ''}`);
    resetUpload();
  } catch (err) {
    showError('Terjadi kesalahan: ' + err.message);
    btn.disabled = false;
    text.textContent = 'Import ke Database';
    spinner.style.display = 'none';
  }
}

function downloadTemplate() {
  // Template dengan struktur baru sesuai Excel
  const csv = `SKU,ISBN,Judul,Penulis,Kategori,SubKategori,Tahun,Ukuran,Halaman,Spek,Harga
DP12396A,978-634-0,Petualangan Seru,Endang Fachrudin,UMUM,Anak-Anak,2025,C5,280,FC Bookpaper,735000
DP12396B,978-634-1,Algoritma Modern,John Doe; Jane Smith,ILMU,Komputer,2023,A4,450,Kertas Premium,550000
DP12396C,978-634-2,Database Design,Sarah Johnson,TEKNIK,Database,2021,B5,380,Glossy Paper,425000

# Format:
# - SKU: Kode buku unik (opsional)
# - ISBN: Wajib diisi
# - Judul: Wajib diisi
# - Penulis: Pisahkan dengan semicolon jika lebih dari satu
# - Kategori: Kategori utama
# - SubKategori: Sub kategori
# - Tahun: Tahun penerbitan (4 digit)
# - Ukuran: Ukuran buku (C5, A4, B5, dll)
# - Halaman: Jumlah halaman (angka saja)
# - Spek: Spesifikasi/jenis kertas
# - Harga: Harga (angka saja, tanpa Rp)`;

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'template_buku.csv';
  link.click();
}

function resetUpload() {
  fileInput.value = '';
  parsedData = null;
  previewSection.classList.remove('show');
  document.querySelector('#preview-table tbody').innerHTML = '';
  document.querySelector('#preview-table thead').innerHTML = '';
}

function showError(msg) {
  errorMsg.textContent = msg;
  errorMsg.classList.add('show');
  successMsg.classList.remove('show');
}

function hideError() {
  errorMsg.classList.remove('show');
}

function hideSuccess() {
  successMsg.classList.remove('show');
}

function showSuccess(msg) {
  successMsg.textContent = msg;
  successMsg.classList.add('show');
  errorMsg.classList.remove('show');
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

// Check if XLSX library is loaded and provide fallback
window.addEventListener('load', function() {
  if (typeof XLSX === 'undefined') {
    console.warn('XLSX library failed to load from CDN, loading fallback...');
    // Load from alternative CDN
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js';
    script.onerror = function() {
      console.error('Failed to load XLSX library from all sources');
    };
    document.head.appendChild(script);
  }
});
</script>
</body>
</html>
